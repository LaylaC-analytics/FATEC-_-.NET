﻿Imports System.Data.SqlClient

Public Class Conexao

    Public Shared Function GetConnection() As SqlConnection
        Return New SqlConnection("Server=LAB5-05;Database=ProdutosDB;Trusted_Connection=True;")
    End Function

End Class