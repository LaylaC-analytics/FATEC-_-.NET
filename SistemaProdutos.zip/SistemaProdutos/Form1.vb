﻿Imports System.Data.SqlClient

Public Class Form1

    Dim caminhoImagem As String

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Salvar.Click

        ' VALIDAÇÃO
        If Descrição.Text = "" Then
            MessageBox.Show("Preencha a descrição!")
            Exit Sub
        End If

        If Not IsNumeric(Quantidade.Text) Then
            MessageBox.Show("Quantidade inválida!")
            Exit Sub
        End If

        Using con = Conexao.GetConnection()

            Dim query As String = "INSERT INTO PRODUTOS 
(DESCRICAO, DATA_LOTE, CATEGORIA, MARCA, QUANTIDADE, PRECO_CUSTO, PRECO_VENDA, FOTO)
VALUES (@desc, @data, @cat, @marca, @qtd, @pc, @pv, @foto)"

            Using cmd As New SqlClient.SqlCommand(query, con)

                cmd.Parameters.AddWithValue("@desc", Descrição.Text)
                cmd.Parameters.AddWithValue("@data", Data_do_Lote.Value)
                cmd.Parameters.AddWithValue("@cat", Categoria.Text)
                cmd.Parameters.AddWithValue("@marca", Marca.Text)
                cmd.Parameters.AddWithValue("@qtd", CInt(Quantidade.Text))
                cmd.Parameters.AddWithValue("@pc", CDec(Preço_Custo.Text))
                cmd.Parameters.AddWithValue("@pv", CDec(Preço_Venda.Text))

                ' FOTO DENTRO DO USING
                If Not String.IsNullOrEmpty(caminhoImagem) Then
                    cmd.Parameters.AddWithValue("@foto", ConverterImagem())
                Else
                    cmd.Parameters.AddWithValue("@foto", DBNull.Value)
                End If

                con.Open()
                cmd.ExecuteNonQuery()

            End Using

            MessageBox.Show("Produto salvo com sucesso!")

                CarregarProdutos()

                'LIMPAR CAMPOS
                Descrição.Clear()
                Categoria.Clear()
                Marca.Clear()
                Quantidade.Clear()
                Preço_Custo.Clear()
                Preço_Venda.Clear()
                Foto_Produto.Image = Nothing
                caminhoImagem = ""


        End Using

    End Sub

    Private Sub Data_do_Lote_ValueChanged(sender As Object, e As EventArgs) Handles Data_do_Lote.ValueChanged

    End Sub

    Public Sub CarregarProdutos()

        Using con = Conexao.GetConnection()

            Dim query As String = "
        SELECT 
            DESCRICAO,
            CATEGORIA,
            MARCA,
            QUANTIDADE,
            PRECO_VENDA,
            (PRECO_VENDA - PRECO_CUSTO) AS MARGEM_LUCRO
        FROM PRODUTOS"

            Dim da As New SqlDataAdapter(query, con)
            Dim dt As New DataTable()

            da.Fill(dt)
            DataGridView1.DataSource = dt

        End Using

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CarregarProdutos()
    End Sub

    Public Sub PesquisarProdutos(termo As String)

        Using con = Conexao.GetConnection()

            Dim query As String = "
        SELECT 
            DESCRICAO,
            CATEGORIA,
            MARCA,
            QUANTIDADE,
            PRECO_VENDA,
            (PRECO_VENDA - PRECO_CUSTO) AS MARGEM_LUCRO
        FROM PRODUTOS
        WHERE 
            DESCRICAO LIKE @termo OR
            CATEGORIA LIKE @termo OR
            MARCA LIKE @termo"

            Dim cmd As New SqlCommand(query, con)
            cmd.Parameters.AddWithValue("@termo", "%" & termo & "%")

            Dim da As New SqlDataAdapter(cmd)
            Dim dt As New DataTable()

            da.Fill(dt)
            DataGridView1.DataSource = dt

        End Using

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Buscar.Click

        ' ✅ CORREÇÃO AQUI (usar TextBox, não o botão)
        PesquisarProdutos(Buscar.Text)

    End Sub

    Private Sub btnImagem_Click(sender As Object, e As EventArgs) Handles btnImagem.Click

        Dim dialog As New OpenFileDialog()

        dialog.Filter = "Imagens|*.jpg;*.png;*.jpeg"

        If dialog.ShowDialog() = DialogResult.OK Then
            caminhoImagem = dialog.FileName
            Foto_Produto.Image = Image.FromFile(caminhoImagem)
        End If

    End Sub

    Public Function ConverterImagem() As Byte()

        If Not String.IsNullOrEmpty(caminhoImagem) Then
            Return IO.File.ReadAllBytes(caminhoImagem)
        Else
            Return Nothing
        End If

    End Function
End Class