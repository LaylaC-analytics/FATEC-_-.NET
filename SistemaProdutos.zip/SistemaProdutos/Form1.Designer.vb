﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Descrição = New System.Windows.Forms.TextBox()
        Me.Categoria = New System.Windows.Forms.TextBox()
        Me.Marca = New System.Windows.Forms.TextBox()
        Me.Quantidade = New System.Windows.Forms.TextBox()
        Me.Preço_Custo = New System.Windows.Forms.TextBox()
        Me.Preço_Venda = New System.Windows.Forms.TextBox()
        Me.Data_do_Lote = New System.Windows.Forms.DateTimePicker()
        Me.Foto_Produto = New System.Windows.Forms.PictureBox()
        Me.Salvar = New System.Windows.Forms.Button()
        Me.Buscar = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnImagem = New System.Windows.Forms.Button()
        CType(Me.Foto_Produto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Descrição
        '
        Me.Descrição.Location = New System.Drawing.Point(33, 76)
        Me.Descrição.Name = "Descrição"
        Me.Descrição.Size = New System.Drawing.Size(100, 20)
        Me.Descrição.TabIndex = 0
        '
        'Categoria
        '
        Me.Categoria.Location = New System.Drawing.Point(33, 137)
        Me.Categoria.Name = "Categoria"
        Me.Categoria.Size = New System.Drawing.Size(100, 20)
        Me.Categoria.TabIndex = 1
        '
        'Marca
        '
        Me.Marca.Location = New System.Drawing.Point(33, 194)
        Me.Marca.Name = "Marca"
        Me.Marca.Size = New System.Drawing.Size(100, 20)
        Me.Marca.TabIndex = 2
        '
        'Quantidade
        '
        Me.Quantidade.Location = New System.Drawing.Point(33, 242)
        Me.Quantidade.Name = "Quantidade"
        Me.Quantidade.Size = New System.Drawing.Size(100, 20)
        Me.Quantidade.TabIndex = 3
        '
        'Preço_Custo
        '
        Me.Preço_Custo.Location = New System.Drawing.Point(33, 308)
        Me.Preço_Custo.Name = "Preço_Custo"
        Me.Preço_Custo.Size = New System.Drawing.Size(100, 20)
        Me.Preço_Custo.TabIndex = 4
        '
        'Preço_Venda
        '
        Me.Preço_Venda.Location = New System.Drawing.Point(33, 353)
        Me.Preço_Venda.Name = "Preço_Venda"
        Me.Preço_Venda.Size = New System.Drawing.Size(100, 20)
        Me.Preço_Venda.TabIndex = 5
        '
        'Data_do_Lote
        '
        Me.Data_do_Lote.Location = New System.Drawing.Point(558, 37)
        Me.Data_do_Lote.Name = "Data_do_Lote"
        Me.Data_do_Lote.Size = New System.Drawing.Size(200, 20)
        Me.Data_do_Lote.TabIndex = 6
        '
        'Foto_Produto
        '
        Me.Foto_Produto.Location = New System.Drawing.Point(229, 93)
        Me.Foto_Produto.Name = "Foto_Produto"
        Me.Foto_Produto.Size = New System.Drawing.Size(100, 280)
        Me.Foto_Produto.TabIndex = 7
        Me.Foto_Produto.TabStop = False
        '
        'Salvar
        '
        Me.Salvar.Location = New System.Drawing.Point(558, 415)
        Me.Salvar.Name = "Salvar"
        Me.Salvar.Size = New System.Drawing.Size(75, 23)
        Me.Salvar.TabIndex = 10
        Me.Salvar.Text = "Salvar"
        Me.Salvar.UseVisualStyleBackColor = True
        '
        'Buscar
        '
        Me.Buscar.Location = New System.Drawing.Point(683, 415)
        Me.Buscar.Name = "Buscar"
        Me.Buscar.Size = New System.Drawing.Size(75, 23)
        Me.Buscar.TabIndex = 11
        Me.Buscar.Text = "Pesquisar"
        Me.Buscar.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(395, 93)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(363, 280)
        Me.DataGridView1.TabIndex = 13
        '
        'btnImagem
        '
        Me.btnImagem.Location = New System.Drawing.Point(261, 404)
        Me.btnImagem.Name = "btnImagem"
        Me.btnImagem.Size = New System.Drawing.Size(75, 23)
        Me.btnImagem.TabIndex = 14
        Me.btnImagem.Text = "Button1"
        Me.btnImagem.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnImagem)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Buscar)
        Me.Controls.Add(Me.Salvar)
        Me.Controls.Add(Me.Foto_Produto)
        Me.Controls.Add(Me.Data_do_Lote)
        Me.Controls.Add(Me.Preço_Venda)
        Me.Controls.Add(Me.Preço_Custo)
        Me.Controls.Add(Me.Quantidade)
        Me.Controls.Add(Me.Marca)
        Me.Controls.Add(Me.Categoria)
        Me.Controls.Add(Me.Descrição)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.Foto_Produto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Descrição As TextBox
    Friend WithEvents Categoria As TextBox
    Friend WithEvents Marca As TextBox
    Friend WithEvents Quantidade As TextBox
    Friend WithEvents Preço_Custo As TextBox
    Friend WithEvents Preço_Venda As TextBox
    Friend WithEvents Data_do_Lote As DateTimePicker
    Friend WithEvents Foto_Produto As PictureBox
    Friend WithEvents Salvar As Button
    Friend WithEvents Buscar As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnImagem As Button
End Class
