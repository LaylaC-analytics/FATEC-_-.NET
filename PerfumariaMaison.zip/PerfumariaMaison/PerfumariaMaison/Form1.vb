﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If Sessao.TipoUsuario Is Nothing Then
            MessageBox.Show("Faça login primeiro")

            Me.Hide()

            Dim login As New login()
            login.ShowDialog()

            If Sessao.TipoUsuario Is Nothing Then
                Me.Close()
                Exit Sub
            End If

            Me.Show()
        End If

        If Sessao.TipoUsuario = "Admin" Then

            PRODUTOSToolStripMenuItem.Enabled = True
            USUARIOSToolStripMenuItem.Enabled = True
            CLIENTESToolStripMenuItem.Enabled = True
            VENDASToolStripMenuItem.Enabled = True

        ElseIf Sessao.TipoUsuario = "Usuario" Then

            PRODUTOSToolStripMenuItem.Enabled = False
            USUARIOSToolStripMenuItem.Enabled = False
            CLIENTESToolStripMenuItem.Enabled = True
            VENDASToolStripMenuItem.Enabled = True

        Else

            MessageBox.Show("Tipo de usuário inválido")
            Me.Close()

        End If

    End Sub

    Private Sub PRODUTOSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PRODUTOSToolStripMenuItem.Click
        If Sessao.TipoUsuario <> "Admin" Then Exit Sub
        Dim f As New CadastroProduto
        f.Show()
    End Sub

    Private Sub CLIENTESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CLIENTESToolStripMenuItem.Click
        Dim f As New Clientes
        f.Show()
    End Sub

    Private Sub VENDASToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VENDASToolStripMenuItem.Click
        Dim f As New Compras
        f.Show()
    End Sub

    Private Sub USUARIOSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles USUARIOSToolStripMenuItem.Click
        If Sessao.TipoUsuario <> "Admin" Then Exit Sub
        Dim f As New CadastroUsuario
        f.Show()
    End Sub

    Private Sub LOGINToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LOGINToolStripMenuItem.Click
        Dim f As New login
        f.Show()
    End Sub

    Private Sub COMPRASToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles COMPRASToolStripMenuItem.Click
        Dim f As New Compras
        f.Show()
    End Sub

End Class