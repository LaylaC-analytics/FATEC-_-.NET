﻿Imports System.Data.SqlClient


Public Class Compras

    Private Sub Compras_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If Sessao.TipoUsuario Is Nothing Then
            MessageBox.Show("Faça login primeiro")
            Me.Close()
            Exit Sub
        End If

        Using conn = Conexao.GetConnection()
            conn.Open()

            Dim cmd As New SqlCommand("SELECT Id, Nome FROM Produtos", conn)
            Dim reader = cmd.ExecuteReader()

            Dim tabela As New List(Of Object)

            While reader.Read()
                tabela.Add(New With {
                    .Text = reader("Nome").ToString(),
                    .Value = Convert.ToInt32(reader("Id"))
                })
            End While

            reader.Close()

            Produto.DataSource = tabela
            Produto.DisplayMember = "Text"
            Produto.ValueMember = "Value"

        End Using

    End Sub


    Private Sub button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If Produto.SelectedItem Is Nothing Then
            MessageBox.Show("Selecione um produto")
            Exit Sub
        End If

        Dim quantidade As Integer

        If Not Integer.TryParse(txtQuantidade.Text, quantidade) OrElse quantidade <= 0 Then
            MessageBox.Show("Quantidade inválida")
            Exit Sub
        End If

        Dim produtoSelecionado = Produto.SelectedItem
        Dim produtoId = produtoSelecionado.Value

        Using conn = Conexao.GetConnection()
            conn.Open()

            Dim cmdEstoque As New SqlCommand("SELECT Estoque, Preco FROM Produtos WHERE Id=@id", conn)
            cmdEstoque.Parameters.AddWithValue("@id", produtoId)

            Dim reader = cmdEstoque.ExecuteReader()

            If Not reader.Read() Then
                reader.Close()
                MessageBox.Show("Produto não encontrado")
                Exit Sub
            End If

            Dim estoque = Convert.ToInt32(reader("Estoque"))
            Dim preco = Convert.ToDecimal(reader("Preco"))

            reader.Close()

            If quantidade > estoque Then
                MessageBox.Show("Estoque insuficiente")
                Exit Sub
            End If

            Dim total = preco * quantidade

            Dim cmdCompra As New SqlCommand("
            INSERT INTO Compras (ClienteId, UsuarioId, Total, FormaPagamento)
            OUTPUT INSERTED.Id
            VALUES (1,@u,@t,'Dinheiro')", conn)

            cmdCompra.Parameters.AddWithValue("@u", Sessao.UsuarioId)
            cmdCompra.Parameters.AddWithValue("@t", total)

            Dim compraId = Convert.ToInt32(cmdCompra.ExecuteScalar())

            Dim cmdItem As New SqlCommand("
            INSERT INTO CompraItens (CompraId, ProdutoId, Quantidade, Preco)
            VALUES (@c,@p,@q,@pr)", conn)

            cmdItem.Parameters.AddWithValue("@c", compraId)
            cmdItem.Parameters.AddWithValue("@p", produtoId)
            cmdItem.Parameters.AddWithValue("@q", quantidade)
            cmdItem.Parameters.AddWithValue("@pr", preco)

            cmdItem.ExecuteNonQuery()

            Dim cmdUpdate As New SqlCommand("
            UPDATE Produtos
            SET Estoque = Estoque - @q
            WHERE Id=@id", conn)

            cmdUpdate.Parameters.AddWithValue("@q", quantidade)
            cmdUpdate.Parameters.AddWithValue("@id", produtoId)

            cmdUpdate.ExecuteNonQuery()

        End Using

        MessageBox.Show("Compra realizada com sucesso!")

    End Sub
End Class