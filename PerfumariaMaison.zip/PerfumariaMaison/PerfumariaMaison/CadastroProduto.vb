﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement


Public Class CadastroProduto

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If Sessao.TipoUsuario <> "Admin" Then
            MessageBox.Show("Acesso negado")
            Exit Sub
        End If

        Dim conn = Conexao.GetConnection()
        conn.Open()

        Dim cmd As New SqlCommand("
            INSERT INTO Produtos (Nome, Preco, Estoque)
            VALUES (@n, @p, @e)", conn)

        cmd.Parameters.AddWithValue("@n", Nome.Text)
        cmd.Parameters.AddWithValue("@p", Decimal.Parse(Preço.Text))
        cmd.Parameters.AddWithValue("@e", Integer.Parse(Quantidade.Text))

        cmd.ExecuteNonQuery()
        conn.Close()

        MessageBox.Show("Produto cadastrado com sucesso!")

    End Sub

    Private Sub CadastroProduto_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If Sessao.TipoUsuario <> "Admin" Then
            MessageBox.Show("Acesso negado")

            Me.Close()
        End If

    End Sub

End Class