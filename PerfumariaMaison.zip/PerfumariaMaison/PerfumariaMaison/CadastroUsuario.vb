﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement




Public Class CadastroUsuario

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If usuario.Text.Trim() = "" Or senha.Text.Trim() = "" Then
            MessageBox.Show("Preencha todos os campos")
            Exit Sub
        End If

        Using conn = Conexao.GetConnection()
            conn.Open()

            Using cmd As New SqlCommand("
                INSERT INTO Usuarios (Login, Senha, Tipo)
                VALUES (@l, @s, @t)", conn)

                cmd.Parameters.AddWithValue("@l", usuario.Text.Trim())
                cmd.Parameters.AddWithValue("@s", senha.Text.Trim())
                cmd.Parameters.AddWithValue("@t", "Usuario")

                cmd.ExecuteNonQuery()

            End Using
        End Using

        MessageBox.Show("Usuário cadastrado com sucesso!")

    End Sub

    Private Sub CadastroUsuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If Sessao.TipoUsuario <> "Admin" Then
            MessageBox.Show("Acesso negado")
            Me.Close()
            Exit Sub
        End If

    End Sub

End Class