﻿Imports System.Data.SqlClient

Public Class Clientes

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If Nome.Text.Trim() = "" Or Telefone.Text.Trim() = "" Then
            MessageBox.Show("Preencha todos os campos")
            Exit Sub
        End If

        Using conn = Conexao.GetConnection()
            conn.Open()

            Using cmd As New SqlCommand("
                INSERT INTO Clientes (Nome, Telefone)
                VALUES (@n, @t)", conn)

                cmd.Parameters.AddWithValue("@n", Nome.Text.Trim())
                cmd.Parameters.AddWithValue("@t", Telefone.Text.Trim())

                cmd.ExecuteNonQuery()

            End Using
        End Using

        MessageBox.Show("Cliente cadastrado com sucesso!")

    End Sub

    Private Sub Clientes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' sem bloqueio
    End Sub

End Class