﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Vendas ' (ideal renomear para Compras)

    Private Sub Vendas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If Sessao.TipoUsuario Is Nothing Then
            MessageBox.Show("Faça login primeiro")
            Me.Close()
            Exit Sub
        End If

        Dim conn = Conexao.GetConnection()
        conn.Open()

        Dim daProdutos As New SqlDataAdapter("SELECT Id, Nome FROM Produtos WHERE Estoque > 0", conn)
        Dim dtProdutos As New DataTable()
        daProdutos.Fill(dtProdutos)

        Produto.DataSource = dtProdutos
        Produto.DisplayMember = "Nome"
        Produto.ValueMember = "Id"

        Dim daClientes As New SqlDataAdapter("SELECT Id, Nome FROM Clientes", conn)
        Dim dtClientes As New DataTable()
        daClientes.Fill(dtClientes)

        Cliente.DataSource = dtClientes
        Cliente.DisplayMember = "Nome"
        Cliente.ValueMember = "Id"

        conn.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If Sessao.TipoUsuario = Nothing Then
            MessageBox.Show("Faça login primeiro")
            Exit Sub
        End If

        If Produto.SelectedValue Is Nothing Or Cliente.SelectedValue Is Nothing Then
            MessageBox.Show("Selecione cliente e produto")
            Exit Sub
        End If

        Dim quantidade As Integer
        If Not Integer.TryParse(txtQuantidade.Text, quantidade) Then
            MessageBox.Show("Quantidade inválida")
            Exit Sub
        End If

        Dim conn = Conexao.GetConnection()

        Try
            conn.Open()

            ' 🔎 Estoque
            Dim cmdEstoque As New SqlCommand("SELECT Estoque FROM Produtos WHERE Id=@id", conn)
            cmdEstoque.Parameters.AddWithValue("@id", Produto.SelectedValue)

            Dim estoqueAtual As Integer = Convert.ToInt32(cmdEstoque.ExecuteScalar())

            If quantidade > estoqueAtual Then
                MessageBox.Show("Estoque insuficiente!")
                Exit Sub
            End If

            ' 💰 Preço
            Dim cmdPreco As New SqlCommand("SELECT Preco FROM Produtos WHERE Id=@id", conn)
            cmdPreco.Parameters.AddWithValue("@id", Produto.SelectedValue)

            Dim preco As Decimal = Convert.ToDecimal(cmdPreco.ExecuteScalar())
            Dim total As Decimal = preco * quantidade

            ' 🧾 Compra (antes: Venda)
            Dim cmdCompra As New SqlCommand("
                INSERT INTO Compras (ClienteId, UsuarioId, Total, FormaPagamento)
                OUTPUT INSERTED.Id
                VALUES (@c,@u,@t,@p)", conn)

            cmdCompra.Parameters.AddWithValue("@c", Cliente.SelectedValue)
            cmdCompra.Parameters.AddWithValue("@u", Sessao.UsuarioId)
            cmdCompra.Parameters.AddWithValue("@t", total)
            cmdCompra.Parameters.AddWithValue("@p", "Dinheiro")

            Dim compraId As Integer = Convert.ToInt32(cmdCompra.ExecuteScalar())

            ' 📦 Item
            Dim cmdItem As New SqlCommand("
                INSERT INTO CompraItens (CompraId, ProdutoId, Quantidade, Preco)
                VALUES (@v,@p,@q,@preco)", conn)

            cmdItem.Parameters.AddWithValue("@v", compraId)
            cmdItem.Parameters.AddWithValue("@p", Produto.SelectedValue)
            cmdItem.Parameters.AddWithValue("@q", quantidade)
            cmdItem.Parameters.AddWithValue("@preco", preco)

            cmdItem.ExecuteNonQuery()

            ' 📉 Estoque
            Dim cmdUpdate As New SqlCommand("
                UPDATE Produtos 
                SET Estoque = Estoque - @q 
                WHERE Id=@id", conn)

            cmdUpdate.Parameters.AddWithValue("@q", quantidade)
            cmdUpdate.Parameters.AddWithValue("@id", Produto.SelectedValue)

            cmdUpdate.ExecuteNonQuery()

            MessageBox.Show("Compra realizada com sucesso!")

        Finally
            conn.Close()
        End Try

    End Sub

End Class