﻿Imports System.Data.SqlClient


Public Class Conexao
    Public Shared Function GetConnection() As SqlConnection
        Return New SqlConnection("Data Source=localhost;Initial Catalog=PerfumariaDB;Integrated Security=True")
    End Function
End Class