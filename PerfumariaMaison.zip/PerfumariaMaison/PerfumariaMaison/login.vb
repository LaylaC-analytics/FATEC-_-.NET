﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement


Public Class Sessao
    Public Shared UsuarioId As Integer
    Public Shared NomeUsuario As String
    Public Shared TipoUsuario As String
End Class

Public Class login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim conn = Conexao.GetConnection()
        conn.Open()

        Dim cmd As New SqlCommand("SELECT Id, Nome, Tipo FROM Usuarios WHERE Login=@l AND Senha=@s", conn)
        cmd.Parameters.AddWithValue("@l", usuario.Text)
        cmd.Parameters.AddWithValue("@s", senha.Text)

        Dim reader As SqlDataReader = cmd.ExecuteReader()

        If reader.Read() Then

            Sessao.UsuarioId = Convert.ToInt32(reader("Id"))
            Sessao.NomeUsuario = reader("Nome").ToString()
            Sessao.TipoUsuario = reader("Tipo").ToString()

            MessageBox.Show("Login OK")

            Form1.Show()
            Me.Hide()

        Else
            MessageBox.Show("Usuário ou senha inválidos")
        End If

        reader.Close()
        conn.Close()
    End Sub

    Private Sub login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class

