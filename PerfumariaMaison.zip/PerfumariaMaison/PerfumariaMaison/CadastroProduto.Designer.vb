﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CadastroProduto
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Nome = New System.Windows.Forms.TextBox()
        Me.Preço = New System.Windows.Forms.TextBox()
        Me.Quantidade = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Nome
        '
        Me.Nome.Location = New System.Drawing.Point(74, 70)
        Me.Nome.Name = "Nome"
        Me.Nome.Size = New System.Drawing.Size(668, 20)
        Me.Nome.TabIndex = 6
        '
        'Preço
        '
        Me.Preço.Location = New System.Drawing.Point(74, 216)
        Me.Preço.Name = "Preço"
        Me.Preço.Size = New System.Drawing.Size(668, 20)
        Me.Preço.TabIndex = 7
        '
        'Quantidade
        '
        Me.Quantidade.Location = New System.Drawing.Point(74, 359)
        Me.Quantidade.Name = "Quantidade"
        Me.Quantidade.Size = New System.Drawing.Size(668, 20)
        Me.Quantidade.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(71, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Nome Produto"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(71, 183)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Preço Produto"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(71, 322)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Quantidade Produto"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(494, 411)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(248, 39)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Cadastrar Produto"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CadastroProduto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(235, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Quantidade)
        Me.Controls.Add(Me.Preço)
        Me.Controls.Add(Me.Nome)
        Me.Name = "CadastroProduto"
        Me.Text = "CadastroProduto"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Nome As TextBox
    Friend WithEvents Preço As TextBox
    Friend WithEvents Quantidade As TextBox
    Public WithEvents Label1 As Label
    Public WithEvents Label2 As Label
    Public WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
End Class
